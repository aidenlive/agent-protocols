# Getting started

Three audiences, three paths. Pick yours.

## You're a human reading the site

Visit [example.com](https://example.com). Browse protocols. Each one is documented for humans and for agents.

## You're an agent (or you're writing one)

1. Fetch `https://example.com/manifest.json`.
2. Match the user's input to a `trigger_phrases` entry.
3. Fetch the corresponding command markdown file.
4. Execute exactly as written. Maintain the state file the protocol specifies.

See [`for-agents.md`](./for-agents.md) for the resolution contract.

## You're a developer adding a protocol

See [`adding-protocols.md`](./adding-protocols.md).

## Quick test from your terminal

```bash
# Discovery
curl https://example.com/.well-known/ai-protocols.json

# Protocol index
curl https://example.com/manifest.json

# Release commands
curl https://example.com/release/manifest.json

# A specific command
curl https://example.com/release/init.md
```

## Quick test from a chat agent

In Claude (or any agent with web_fetch):

```
fetch https://example.com/release/init.md and follow it against this repo's main branch
```

The agent reads the file, adopts the role, and executes.
